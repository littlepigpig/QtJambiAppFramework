<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>com.trolltech.demos.HelloGL</name>
    <message>
        <location filename="HelloGL.java" line="298"/>
        <source>Hello GL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.demos.HttpServerExample</name>
    <message>
        <location filename="HttpServerExample.java" line="40"/>
        <source>HTTP Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="HttpServerExample.java" line="41"/>
        <source>Unable to start the server: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="HttpServerExample.java" line="60"/>
        <source>Simple HTTP Server</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.demos.PathStrokeWidget</name>
    <message>
        <location filename="PathStrokeWidget.java" line="41"/>
        <source>Path Stroking</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.demos.imageviewer.ImageTableModel</name>
    <message>
        <location filename="imageviewer/ImageTableModel.java" line="93"/>
        <source>loading</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
