<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>com.trolltech.examples.I18N</name>
    <message>
        <location filename="../I18N.java" line="123"/>
        <source>English</source>
        <translation>한국어</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.I18N$MainWindow</name>
    <message>
        <location filename="../I18N.java" line="167"/>
        <source>&amp;File</source>
        <translation>파일&amp;F</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="164"/>
        <source>E&amp;xit</source>
        <translation>종료&amp;X</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="155"/>
        <source>First</source>
        <translation>첫번째</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="173"/>
        <source>Internationalization Example</source>
        <translation>국제화 예제</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="182"/>
        <source>Isometric</source>
        <translation>등측도</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>Language: %1$s</source>
        <translation>언어 : %1$s</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>English</source>
        <translation>한국어</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="183"/>
        <source>Oblique</source>
        <translation>빗각</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="181"/>
        <source>Perspective</source>
        <translation>원근화법</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="156"/>
        <source>Second</source>
        <translation>두번째</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="157"/>
        <source>Third</source>
        <translation>세번째</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="180"/>
        <source>View</source>
        <translation>보기</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="175"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
