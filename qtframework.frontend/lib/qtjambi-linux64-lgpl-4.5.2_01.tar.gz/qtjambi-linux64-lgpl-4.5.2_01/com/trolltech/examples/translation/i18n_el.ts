<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>com.trolltech.examples.I18N</name>
    <message>
        <location filename="../I18N.java" line="123"/>
        <source>English</source>
        <translation>Ελληνικά</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.I18N$MainWindow</name>
    <message>
        <location filename="../I18N.java" line="167"/>
        <source>&amp;File</source>
        <translation>&amp;Αρχείο</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="164"/>
        <source>E&amp;xit</source>
        <translation>Έ&amp;ξοδος</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="155"/>
        <source>First</source>
        <translation>Πρώτο</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="173"/>
        <source>Internationalization Example</source>
        <translation>Παράδειγμα διεθνοποίησης</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="182"/>
        <source>Isometric</source>
        <translation>Ισομετρική</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>Language: %1$s</source>
        <translation>Γλώσσα: %1$s</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>English</source>
        <translation>Ελληνικά</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="183"/>
        <source>Oblique</source>
        <translation>Πλάγια</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="181"/>
        <source>Perspective</source>
        <translation>Προοπτική</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="156"/>
        <source>Second</source>
        <translation>Δεύτερο</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="157"/>
        <source>Third</source>
        <translation>Τρίτο</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="180"/>
        <source>View</source>
        <translation>Όψη</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="175"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
