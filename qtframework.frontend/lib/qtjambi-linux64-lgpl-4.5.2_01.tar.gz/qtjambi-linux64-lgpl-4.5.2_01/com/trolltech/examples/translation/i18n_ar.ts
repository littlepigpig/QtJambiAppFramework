<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>com.trolltech.examples.I18N</name>
    <message>
        <location filename="../I18N.java" line="123"/>
        <source>English</source>
        <translation>العربية</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.I18N$MainWindow</name>
    <message>
        <location filename="../I18N.java" line="155"/>
        <source>First</source>
        <translation>أول</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="173"/>
        <source>Internationalization Example</source>
        <translation>مثال التدويل</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="182"/>
        <source>Isometric</source>
        <translation>متماثل</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>Language: %1$s</source>
        <translation>اللغة: %1$s</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>English</source>
        <translation>العربية</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="183"/>
        <source>Oblique</source>
        <translation>مصمت</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="181"/>
        <source>Perspective</source>
        <translation>منظور</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="156"/>
        <source>Second</source>
        <translation>ثانى</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="157"/>
        <source>Third</source>
        <translation>ثالث</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="180"/>
        <source>View</source>
        <translation>مرئى</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="164"/>
        <source>E&amp;xit</source>
        <translation>أخرج</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="167"/>
        <source>&amp;File</source>
        <translation>الملف</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="175"/>
        <source>LTR</source>
        <translation>RTL</translation>
    </message>
</context>
</TS>
