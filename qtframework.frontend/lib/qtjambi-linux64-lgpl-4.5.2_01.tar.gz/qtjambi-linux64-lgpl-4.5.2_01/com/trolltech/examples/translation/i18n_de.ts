<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>com.trolltech.examples.I18N</name>
    <message>
        <location filename="../I18N.java" line="123"/>
        <source>English</source>
        <translation>Deutsch</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.I18N$MainWindow</name>
    <message>
        <location filename="../I18N.java" line="180"/>
        <source>View</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="167"/>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="164"/>
        <source>E&amp;xit</source>
        <translation>Be&amp;enden</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="155"/>
        <source>First</source>
        <translation>Erstens</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="157"/>
        <source>Third</source>
        <translation>Drittens</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>English</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>Language: %1$s</source>
        <translation>Sprache: %1$s</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="183"/>
        <source>Oblique</source>
        <translation>Schief</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="156"/>
        <source>Second</source>
        <translation>Zweitens</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="182"/>
        <source>Isometric</source>
        <translation>Isometrisch</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="181"/>
        <source>Perspective</source>
        <translation>Perspektivisch</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="173"/>
        <source>Internationalization Example</source>
        <translation>Internationalisierungsbeispiel</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="175"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
