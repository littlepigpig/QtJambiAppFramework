<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>com.trolltech.examples.I18N</name>
    <message>
        <location filename="../I18N.java" line="123"/>
        <source>English</source>
        <translation>Русский</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.I18N$MainWindow</name>
    <message>
        <location filename="../I18N.java" line="180"/>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="167"/>
        <source>&amp;File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="164"/>
        <source>E&amp;xit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="155"/>
        <source>First</source>
        <translation>Первый</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="157"/>
        <source>Third</source>
        <translation>Третий</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>Language: %1$s</source>
        <translation>Язык: %1$s</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="170"/>
        <source>English</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="183"/>
        <source>Oblique</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="156"/>
        <source>Second</source>
        <translation>Второй</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="182"/>
        <source>Isometric</source>
        <translation>Изометрический</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="181"/>
        <source>Perspective</source>
        <translation>Перспектива</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="173"/>
        <source>Internationalization Example</source>
        <translation>Пример интернациноализации</translation>
    </message>
    <message>
        <location filename="../I18N.java" line="175"/>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
