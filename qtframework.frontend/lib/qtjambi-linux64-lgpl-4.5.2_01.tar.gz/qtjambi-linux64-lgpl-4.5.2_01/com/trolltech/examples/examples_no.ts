<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="nb_NO">
<defaultcodec></defaultcodec>
<context>
    <name>com.trolltech.examples.Application</name>
    <message>
        <location filename="Application.java" line="117"/>
        <source>About Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="120"/>
        <source>The &lt;b&gt;Application&lt;/b&gt; example demonstrates how to write modern GUI applications using Qt, with a menu bar, toolbars, and a status bar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="130"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="131"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="132"/>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="135"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="136"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="137"/>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="140"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="141"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="142"/>
        <source>Save the document to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="145"/>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="146"/>
        <source>Save the document under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="149"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="150"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="151"/>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="154"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="155"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="156"/>
        <source>Cut the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="159"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="160"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="161"/>
        <source>Copy the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="164"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="165"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="166"/>
        <source>Paste the clipboard&apos;s contents into the current selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="169"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="170"/>
        <source>Show the application&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="173"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="174"/>
        <source>Show the Qt library&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="185"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="193"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="200"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="207"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="212"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="220"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="305"/>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="271"/>
        <source>File loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="288"/>
        <source>File saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="305"/>
        <source>%1$s[*] - %2$s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="244"/>
        <source>The document has been modified.
Save your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="261"/>
        <source>Cannot read file %1$s:
%2$s.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Application.java" line="278"/>
        <source>Cannot write file %1$s:
%2$s.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.CachedTable</name>
    <message>
        <location filename="CachedTable.java" line="57"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CachedTable.java" line="58"/>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CachedTable.java" line="59"/>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CachedTable.java" line="66"/>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CachedTable.java" line="68"/>
        <source>&amp;Revert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CachedTable.java" line="69"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CachedTable.java" line="96"/>
        <source>Cached Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CachedTable.java" line="97"/>
        <source>The database reported an error: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.Calculator</name>
    <message>
        <location filename="Calculator.java" line="45"/>
        <source>Ui selector</source>
        <translation>Grafisk grensesnitt velger</translation>
    </message>
    <message>
        <location filename="Calculator.java" line="46"/>
        <source>Ui configurations:</source>
        <translation>Grafisk grensesnitt konfigurasjon</translation>
    </message>
    <message>
        <location filename="Calculator.java" line="270"/>
        <source>Function selector</source>
        <translation>Funksjons velger</translation>
    </message>
    <message>
        <location filename="Calculator.java" line="271"/>
        <source>Available functions:</source>
        <translation>Tilgjengelige funksjoner:</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.Chat</name>
    <message>
        <location filename="Chat.java" line="92"/>
        <source>! Unknown command: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Chat.java" line="108"/>
        <source>* %1$s has joined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Chat.java" line="128"/>
        <source>* %1$s has left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Chat.java" line="134"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Chat.java" line="135"/>
        <source>Launch several instances of this program on your local network and start chatting!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.ConfigDialog</name>
    <message>
        <location filename="ConfigDialog.java" line="38"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="60"/>
        <source>Config Dialog</source>
        <translation>Konfigurasjons Dialog</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="67"/>
        <source>Configuration</source>
        <translation>Konfigurasjon</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="74"/>
        <source>Update</source>
        <translation>Oppdater</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="81"/>
        <source>Query</source>
        <translation>Spørring</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.ConfigDialog$ConfigurationPage</name>
    <message>
        <location filename="ConfigDialog.java" line="98"/>
        <source>Server configuration</source>
        <translation>Server konfigurasjon</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="100"/>
        <source>Server:</source>
        <translation>Server:</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="102"/>
        <source>Trolltech (Australia)</source>
        <translation>Trolltech (Australia)</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="103"/>
        <source>Trolltech (Germany)</source>
        <translation>Trolltech (Tyskland)</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="104"/>
        <source>Trolltech (Norway)</source>
        <translation>Trolltech (Norge)</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="105"/>
        <source>Trolltech (People&apos;s Republic of China)</source>
        <translation>Trolltech (Kina)</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="106"/>
        <source>Trolltech (USA)</source>
        <translation>Trolltech (USA)</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.ConfigDialog$QueryPage</name>
    <message>
        <location filename="ConfigDialog.java" line="168"/>
        <source>Look for packages</source>
        <translation>Let etter pakke</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="170"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="173"/>
        <source>Released after:</source>
        <translation>Utgitt etter:</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="176"/>
        <source>Releases</source>
        <translation>Utgivelser:</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="177"/>
        <source>Upgrades</source>
        <translation>Oppgraderinger</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="179"/>
        <source>Return up to </source>
        <translation type="obsolete">Lever opp til</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="180"/>
        <source> results</source>
        <translation type="obsolete">Resultat</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="182"/>
        <source>Return only the first result</source>
        <translation>Returner bare første resultat</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="187"/>
        <source>Start query</source>
        <translation>Start spørring</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="180"/>
        <source>Return up to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="181"/>
        <source>results</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.ConfigDialog$UpdatePage</name>
    <message>
        <location filename="ConfigDialog.java" line="127"/>
        <source>Package selection</source>
        <translation>Pakke utvalg</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="128"/>
        <source>Update system</source>
        <translation>Oppdater systemet</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="129"/>
        <source>Update applications</source>
        <translation>Oppdater programmene</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="130"/>
        <source>Update documentation</source>
        <translation>Oppdater dokumentasjon</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="132"/>
        <source>Existing packages</source>
        <translation>Eksisterendes pakker</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="136"/>
        <source>Qt</source>
        <translation>Qt</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="138"/>
        <source>QSA</source>
        <translation>QSA</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="140"/>
        <source>Teambuilder</source>
        <translation>Teambuilder</translation>
    </message>
    <message>
        <location filename="ConfigDialog.java" line="142"/>
        <source>Start update</source>
        <translation>Start oppdatering</translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.Connection</name>
    <message>
        <location filename="Chat.java" line="288"/>
        <source>undefined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Chat.java" line="289"/>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.CustomFilter</name>
    <message>
        <location filename="CustomFilter.java" line="60"/>
        <source>Original Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="64"/>
        <source>&amp;Filter pattern:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="68"/>
        <source>Regular expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="70"/>
        <source>Wildcard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="72"/>
        <source>Fixed string</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="76"/>
        <source>Case sensitive filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="80"/>
        <source>F&amp;rom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="84"/>
        <source>&amp;To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="113"/>
        <source>Sorted/Filtered Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="121"/>
        <source>Custom Sort/Filter Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="140"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="141"/>
        <source>Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CustomFilter.java" line="142"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.DomBookmarks</name>
    <message>
        <location filename="DomBookmarks.java" line="51"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="53"/>
        <source>DOM Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="60"/>
        <source>Open Bookmark File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="81"/>
        <source>XBEL Files (*.xbel *.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="87"/>
        <source>SAX Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="67"/>
        <source>Cannot read file: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="73"/>
        <source>File loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="80"/>
        <source>Save Bookmark File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="87"/>
        <source>Cannot write file: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="93"/>
        <source>File saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="100"/>
        <source>About DOM Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="102"/>
        <source>The &lt;b&gt;DOM Bookmarks&lt;/b&gt; example demonstrates how to use Qt&apos;s DOM classes to read and write XML documents.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="106"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="107"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="110"/>
        <source>&amp;Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="111"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="114"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="115"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="118"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="121"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="126"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="133"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.DomBookmarks$XbelTree</name>
    <message>
        <location filename="DomBookmarks.java" line="177"/>
        <source>DOM Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="165"/>
        <source>Parse error at line %s, column %s :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="174"/>
        <source>The file is not an XBEL file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="178"/>
        <source>The file is not an XBEL version 1.0 file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DomBookmarks.java" line="248"/>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.ElasticNodes</name>
    <message>
        <location filename="ElasticNodes.java" line="124"/>
        <source>Elastic Nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ElasticNodes.java" line="206"/>
        <source>Click and drag the nodes around, and zoom with the mouse wheel or the &apos;+&apos; and &apos;-&apos; keys</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.FridgeMagnets</name>
    <message>
        <location filename="FridgeMagnets.java" line="62"/>
        <source>Fridge Magnets</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.GeneratorExample</name>
    <message>
        <location filename="GeneratorExample.java" line="161"/>
        <source>Generator Example</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.I18N</name>
    <message>
        <location filename="I18N.java" line="123"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.ItemviewChart</name>
    <message>
        <location filename="ItemviewChart.java" line="36"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="38"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="39"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="43"/>
        <source>&amp;Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="44"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="48"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="49"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="61"/>
        <source>Chart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="68"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="69"/>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="99"/>
        <source>Choose a data file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="130"/>
        <source>Loaded %s</source>
        <translation type="unfinished">Lastet %s</translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="137"/>
        <source>Save file as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ItemviewChart.java" line="154"/>
        <source>Saved %s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.LineEdits</name>
    <message>
        <location filename="LineEdits.java" line="43"/>
        <source>Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="45"/>
        <source>Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="47"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="48"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="49"/>
        <source>No Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="56"/>
        <source>Validator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="78"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="60"/>
        <source>No validator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="61"/>
        <source>Integer validator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="62"/>
        <source>Double validator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="66"/>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="70"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="71"/>
        <source>Centered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="72"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="76"/>
        <source>Input mask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="80"/>
        <source>No mask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="81"/>
        <source>Phone number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="82"/>
        <source>ISO date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="83"/>
        <source>License key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="87"/>
        <source>Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="89"/>
        <source>Read-only:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="91"/>
        <source>False</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="92"/>
        <source>True</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="LineEdits.java" line="140"/>
        <source>Line Edits</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.MainWindow</name>
    <message>
        <location filename="I18N.java" line="170"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="155"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="156"/>
        <source>Second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="157"/>
        <source>Third</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="164"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="167"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="170"/>
        <source>Language: %1$s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="173"/>
        <source>Internationalization Example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="175"/>
        <source>LTR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="180"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="181"/>
        <source>Perspective</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="182"/>
        <source>Isometric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="I18N.java" line="183"/>
        <source>Oblique</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.Mandelbrot</name>
    <message>
        <location filename="Mandelbrot.java" line="62"/>
        <source>Mandelbrot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Mandelbrot.java" line="74"/>
        <source>Rendering initial image, please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Mandelbrot.java" line="109"/>
        <source>Use mouse wheel to zoom.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Mandelbrot.java" line="109"/>
        <source>Press and hold left mouse button to scroll.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.Menus</name>
    <message>
        <location filename="Menus.java" line="66"/>
        <source>&lt;i&gt;Choose a menu option, or right-click to invoke a context menu&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="86"/>
        <source>A context menu is available by right-clicking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="88"/>
        <source>Menus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="103"/>
        <source>Invoked &lt;b&gt;File|New&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="107"/>
        <source>Invoked &lt;b&gt;File|Open&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="111"/>
        <source>Invoked &lt;b&gt;File|Save&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="115"/>
        <source>Invoked &lt;b&gt;File|Print&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="119"/>
        <source>Invoked &lt;b&gt;Edit|Undo&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="123"/>
        <source>Invoked &lt;b&gt;Edit|Redo&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="127"/>
        <source>Invoked &lt;b&gt;Edit|Cut&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="131"/>
        <source>Invoked &lt;b&gt;Edit|Copy&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="135"/>
        <source>Invoked &lt;b&gt;Edit|Paste&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="139"/>
        <source>Invoked &lt;b&gt;Edit|Format|Bold&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="143"/>
        <source>Invoked &lt;b&gt;Edit|Format|Italic&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="147"/>
        <source>Invoked &lt;b&gt;Edit|Format|Left Align&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="151"/>
        <source>Invoked &lt;b&gt;Edit|Format|Right Align&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="155"/>
        <source>Invoked &lt;b&gt;Edit|Format|Justify&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="159"/>
        <source>Invoked &lt;b&gt;Edit|Format|Center&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="163"/>
        <source>Invoked &lt;b&gt;Edit|Format|Set Line Spacing&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="168"/>
        <source>Invoked &lt;b&gt;Edit|Format|Set Paragraph Spacing&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="172"/>
        <source>Invoked &lt;b&gt;Help|About&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="173"/>
        <source>About Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="175"/>
        <source>The &lt;b&gt;Menu&lt;/b&gt; example shows how to create menu-bar menus and context menus.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="179"/>
        <source>Invoked &lt;b&gt;Help|About Qt&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="184"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="185"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="186"/>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="190"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="191"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="192"/>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="196"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="197"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="198"/>
        <source>Save the document to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="202"/>
        <source>&amp;Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="203"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="204"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="208"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="209"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="210"/>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="214"/>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="215"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="216"/>
        <source>Undo the last operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="220"/>
        <source>&amp;Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="221"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="222"/>
        <source>Redo the last operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="226"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="227"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="228"/>
        <source>Cut the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="232"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="233"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="234"/>
        <source>Copy the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="238"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="239"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="240"/>
        <source>Paste the clipboard&apos;s contents into the current selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="244"/>
        <source>&amp;Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="246"/>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="247"/>
        <source>Make the text bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="255"/>
        <source>&amp;Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="257"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="258"/>
        <source>Make the text italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="266"/>
        <source>Set &amp;Line Spacing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="267"/>
        <source>Change the gap between the lines of a paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="271"/>
        <source>Set &amp;Paragraph Spacing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="273"/>
        <source>Change the gap between paragraphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="277"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="278"/>
        <source>Show the application&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="282"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="283"/>
        <source>Show the Qt library&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="288"/>
        <source>&amp;Left Align</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="290"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="291"/>
        <source>Left align the selected text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="295"/>
        <source>&amp;Right Align</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="297"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="298"/>
        <source>Right align the selected text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="302"/>
        <source>&amp;Justify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="304"/>
        <source>Ctrl+J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="305"/>
        <source>Justify the selected text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="309"/>
        <source>&amp;Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="311"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="312"/>
        <source>Center the selected text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="325"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="333"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="342"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="346"/>
        <source>&amp;Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Menus.java" line="349"/>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.Screenshot</name>
    <message>
        <location filename="Screenshot.java" line="66"/>
        <source>Screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="90"/>
        <source>/untitled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="91"/>
        <source>%1$s Files (*.%2$s);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="94"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="122"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="125"/>
        <source> s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="129"/>
        <source>Screenshot Delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="131"/>
        <source>Hide This Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="141"/>
        <source>New Screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="144"/>
        <source>Save Screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Screenshot.java" line="147"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.ShapedClock</name>
    <message>
        <location filename="ShapedClock.java" line="51"/>
        <source>Shaped Analog Clock</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.SpinBoxes</name>
    <message>
        <location filename="SpinBoxes.java" line="47"/>
        <source>Spin Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="53"/>
        <source>Spinboxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="149"/>
        <source>Enter a value between %1$d and %2$d:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="61"/>
        <source>Enter a zoom value between %1$d and %2$d:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="66"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="163"/>
        <source>Enter a price between %1$d and %2$d:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="87"/>
        <source>Date and time spin boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="92"/>
        <source>Appointment date (between %0$s and %1$s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="99"/>
        <source>Appointment time (between %0$s and %1$s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="106"/>
        <source>Format string for the meeting date and time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="134"/>
        <source>Meeting date (between %0$s and %1$s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="137"/>
        <source>Meeting time (between %0$s and %1$s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="142"/>
        <source>Double precision spinboxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="144"/>
        <source>Number of decimal places to show:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="155"/>
        <source>Enter a scale factor between %1$d and %2$d:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SpinBoxes.java" line="160"/>
        <source>No scaling</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.SqlCommon</name>
    <message>
        <location filename="SqlCommon.java" line="28"/>
        <source>Cannot open database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SqlCommon.java" line="33"/>
        <source>Unable to establish a database connection.
This example needs SQLite support. Please read the Qt SQL driver documentation for information how to build it.

Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.StarWindow</name>
    <message>
        <location filename="StarWindow.java" line="13"/>
        <source>Mass in B-Minor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="13"/>
        <source>Baroque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="13"/>
        <source>JS Bach</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="15"/>
        <source>Sex Bomb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="18"/>
        <source>Pop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="15"/>
        <source>Tom Jones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="16"/>
        <source>Three More Foxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="16"/>
        <source>jazz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="16"/>
        <source>Maynard Ferguson</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="18"/>
        <source>Barbie Girl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="18"/>
        <source>Aqua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="33"/>
        <source>Star Delegate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="50"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="51"/>
        <source>Genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="52"/>
        <source>Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StarWindow.java" line="53"/>
        <source>Rating</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.StyleSheet</name>
    <message>
        <location filename="StyleSheet.java" line="45"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StyleSheet.java" line="61"/>
        <source>About Style sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="StyleSheet.java" line="66"/>
        <source>The &lt;b&gt;Style Sheet&lt;/b&gt; example shows how widgets can be styled using &lt;a href=&quot;http://doc.trolltech.com/4.2/stylesheet.html&quot;&gt;Qt Style Sheets&lt;/a&gt;. Click &lt;b&gt;File|Edit Style Sheet&lt;/b&gt; to pop up the style editor, and either choose an existing style sheet or design your own.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.SyntaxHighlighter</name>
    <message>
        <location filename="SyntaxHighlighter.java" line="42"/>
        <source>Syntax Highlighter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="48"/>
        <source>About Syntax Highlighter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="52"/>
        <source>&lt;p&gt;The &lt;b&gt;Syntax Highlighter&lt;/b&gt; example shows how to perform simple syntax highlighting by subclassing the QSyntaxHighlighter class and describing highlighting rules using regular expressions.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="70"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="100"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="103"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="107"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="111"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="117"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="120"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SyntaxHighlighter.java" line="124"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.SystemTrayExample</name>
    <message>
        <location filename="SystemTrayExample.java" line="67"/>
        <source>System tray is unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="68"/>
        <source>System tray unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="108"/>
        <source>Message Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="110"/>
        <source>Message Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="111"/>
        <source>Man is more ape than many of the apes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="114"/>
        <source>Message Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="124"/>
        <source>Balloon message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="125"/>
        <source>Click here to balloon the message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="128"/>
        <source>Status messages will be visible here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="131"/>
        <source>Show system tray icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="158"/>
        <source>System Tray Example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="167"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="167"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="180"/>
        <source>System tray example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="181"/>
        <source>Balloon tips are not supported on Mac OS X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SystemTrayExample.java" line="192"/>
        <source>Balloon message was clicked</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.tutorial.Blocks</name>
    <message>
        <location filename="tutorial/Blocks.java" line="23"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tutorial/Blocks.java" line="41"/>
        <source>Building Blocks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.tutorial.BlocksGalore</name>
    <message>
        <location filename="tutorial/BlocksGalore.java" line="23"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tutorial/BlocksGalore.java" line="33"/>
        <source>Building Blocks Galore</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.tutorial.ConnectedSliders</name>
    <message>
        <location filename="tutorial/ConnectedSliders.java" line="23"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tutorial/ConnectedSliders.java" line="47"/>
        <source>One Thing Leads to Another</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>com.trolltech.examples.tutorial.Widgets</name>
    <message>
        <location filename="tutorial/Widgets.java" line="24"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tutorial/Widgets.java" line="30"/>
        <source>Let There Be Widgets</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
